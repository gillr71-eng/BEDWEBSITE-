# BED Full Circle Live Portal v1.1

Protected Next.js/Supabase portal for Better Every Day™ Full Circle.

Authorization chain: Supabase Auth → active public organization membership → verified organization bridge → authorized person selector → Full Circle person workspace.

## Auth
Passwordless email sign-in uses `signInWithOtp` with `shouldCreateUser:false`; users must be provisioned. Configure the deployed `/auth/confirm` URL in Supabase Auth redirect URLs.

## Environment
Copy `.env.example` to `.env.local` and provide the project URL and publishable key. Never use a service-role/secret key in the browser.

## Current production-data behavior
The workspace intentionally shows an empty authorized-person state when no protected person profiles exist. It does not accept manually entered person UUIDs.


## v1.2 workspace
The protected workspace now renders the live Full Circle contract as WHO / WHY / WHAT NEXT / PROOF, including person voice, QoL goals, Core Plus assessment metrics, routed action packets, evidence counts, FS-POS placement/transition, BED Intelligence, and the Full Circle outcome question. It intentionally does not invent authority citations: verified statute/rule/settlement/plan crosswalk records must be attached before legal authority is displayed.


## v1.3 Person Workspace UI Integration
The protected workspace now calls the live person dashboard, unified actions, proof panel, learning loop, and Full Circle timeline RPCs. Tabs: Overview, Goals, Assessments, Actions, Life Outcomes, Documents / Proof, Timeline. Production empty-state behavior remains intact; no demo person is inserted.


## v1.4 Production hardening
- Removed the fictional `/person/jordan` route from the protected production package.
- Root `/` now redirects to `/workspace`.
- Added `next.config.mjs` and `.env.example`.
- Validation attempted in the build environment on 2026-09-11; `npm install --no-audit --no-fund` exceeded the 120-second execution window and did not install the Next.js binary, so a clean production build is not yet claimed.
