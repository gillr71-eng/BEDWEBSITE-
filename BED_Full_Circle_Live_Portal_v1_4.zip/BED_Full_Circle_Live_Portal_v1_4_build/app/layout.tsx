import "./globals.css";
export const metadata = {
  title: "BED™ Full Circle Demo",
  description: "Better Every Day™ Full Circle demonstration"
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
