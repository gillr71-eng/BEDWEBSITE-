'use client';
import { FormEvent, useState } from 'react';
import { createClient } from '../../lib/supabase';

export default function SignIn() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault(); setError(''); setMessage(''); setBusy(true);
    const supabase = createClient();
    const redirect = `${window.location.origin}/auth/confirm`;
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { shouldCreateUser: false, emailRedirectTo: redirect }
    });
    setBusy(false);
    if (error) { setError('Unable to send a sign-in link. Confirm that this email has been provisioned for BED access.'); return; }
    setMessage('Check your email for your secure BED sign-in link.');
  }

  return <main className="auth"><form onSubmit={submit} className="authCard">
    <div className="eyebrow">SECURE BED FULL CIRCLE</div><h1>Sign in</h1>
    <p>Use your provisioned email. BED does not create an account from this screen.</p>
    <label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} autoComplete="email" required/></label>
    {error && <p className="error">{error}</p>}{message && <p>{message}</p>}
    <button className="button" disabled={busy}>{busy ? 'Sending…' : 'Email secure sign-in link →'}</button>
  </form></main>;
}
