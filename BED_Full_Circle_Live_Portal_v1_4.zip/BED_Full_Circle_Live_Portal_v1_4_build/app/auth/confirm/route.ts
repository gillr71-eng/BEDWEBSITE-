import { NextRequest, NextResponse } from 'next/server';
import { createServerClient } from '@supabase/ssr';

export async function GET(request: NextRequest) {
  const url = new URL(request.url);
  const tokenHash = url.searchParams.get('token_hash');
  const code = url.searchParams.get('code');
  const response = NextResponse.redirect(new URL('/workspace', url.origin));
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    { cookies: { getAll: () => request.cookies.getAll(), setAll: cookies => cookies.forEach(({name,value,options}) => response.cookies.set(name,value,options)) } }
  );
  let error = null;
  if (tokenHash) ({ error } = await supabase.auth.verifyOtp({ token_hash: tokenHash, type: 'email' }));
  else if (code) ({ error } = await supabase.auth.exchangeCodeForSession(code));
  else return NextResponse.redirect(new URL('/signin?error=invalid_link', url.origin));
  return error ? NextResponse.redirect(new URL('/signin?error=invalid_link', url.origin)) : response;
}
